package org.kuehne.unit;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.kuehne.dtos.Athlete;
import org.kuehne.services.CalculationService;

class CalculationServiceTest {

  private CalculationService calculationService;

  @BeforeEach
  public void initEach() {
    calculationService = new CalculationService();
  }

  @Test
  void test1_calculateTotalPoint() {
    int expectedTotalPoints = 9126;
    Athlete athlete = new Athlete("Test name", "10.55", "7.80", "16.00", "2.05", "48.42", "13.75",
        "50.54",
        "5.45", "71.90", "4:36.11");
    int totalPoints = calculationService.calculateTotalPoint(athlete);

    assertEquals(expectedTotalPoints, totalPoints);
  }
}
