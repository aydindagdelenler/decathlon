package org.kuehne.unit;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import javax.swing.Spring;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.kuehne.Application;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.enums.FileReaderType;
import org.kuehne.exceptions.RequirementException;
import org.kuehne.readers.CSVReader;
import org.kuehne.readers.ReaderFactory;
import org.kuehne.services.CalculationService;
import org.kuehne.services.ReaderService;

class ReaderServiceTest {

  private static final String ALLOWED_FILE_PATH = "src/test/resources/results.csv";
  private static final String UN_ALLOWED_FILE_PATH = "src/test/resources/results.txt";

  private ReaderService readerService;

  @BeforeEach
  public void initEach(){
    readerService = new ReaderService();
  }

  @Test
  void test1_readAllowedFile() {
    readerService.setFileReader(ReaderFactory.chooseReader(FileReaderType.CSV));
    List<Athlete> athletes = readerService.readFile(ALLOWED_FILE_PATH);

    assertEquals(2, athletes.size());
  }

  @Test
  void test2_readUnAllowedFile() {
    String expectedErrorMessage = "File extension is not allowed to use";

    readerService.setFileReader(ReaderFactory.chooseReader(FileReaderType.CSV));
    try {
      readerService.readFile(UN_ALLOWED_FILE_PATH);
    }
    catch (RequirementException r) {
      expectedErrorMessage = r.getMessage();
    }

    assertEquals(expectedErrorMessage, ExceptionCode.EXTENSION_NOT_ALLOWED.getDescription());
  }
}
