package org.kuehne.unit;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.enums.FileReaderType;
import org.kuehne.enums.FileWriterType;
import org.kuehne.exceptions.RequirementException;
import org.kuehne.readers.CSVReader;
import org.kuehne.readers.ReaderFactory;
import org.kuehne.services.ReaderService;
import org.kuehne.services.WriterService;
import org.kuehne.writers.WriterFactory;
import org.kuehne.writers.XMLWriter;

class WriterServiceTest {

  private static final String FILE_PATH = "src/test/resources/results.csv";
  private static final String RESULT_FILE_PATH = "src/test/resources/results.xml";

  private WriterService writerService;

  @BeforeEach
  public void initEach(){
    writerService = new WriterService();
  }

  @Test
  void test1_setValuesAndCreateFile() throws IOException {
    Path fileToDeletePath = Paths.get(RESULT_FILE_PATH);
    Files.deleteIfExists(fileToDeletePath);

    File file = new File(RESULT_FILE_PATH);
    assertFalse(file.exists());

    ReaderService readerService = new ReaderService();
    readerService.setFileReader(ReaderFactory.chooseReader(FileReaderType.CSV));
    List<Athlete> athletes = readerService.readFile(FILE_PATH);

    writerService.setFileWriter(WriterFactory.chooseWriter(FileWriterType.XML));
    writerService.setValuesAndCreateFile(athletes, RESULT_FILE_PATH);

    assertTrue(file.exists());
  }

}
