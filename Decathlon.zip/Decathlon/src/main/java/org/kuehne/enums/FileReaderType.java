package org.kuehne.enums;

/**
 * Enum class for the valid file types
 */
public enum FileReaderType {
  CSV
}
