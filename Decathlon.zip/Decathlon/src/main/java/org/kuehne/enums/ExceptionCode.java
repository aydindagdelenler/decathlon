package org.kuehne.enums;

/**
 * Exception codes and their descriptions to be returned
 * when the custom exception is thrown
 */
public enum ExceptionCode {
  EXTENSION_NOT_ALLOWED("File extension is not allowed to use"),
  EXCEPTION_READING_FILE("Error has bean occurred while file reading process"),
  NOT_ALL_RESULTS_AVAILABLE("All 10 results are not available in the file");

  private final String description;

  ExceptionCode(String description) {
    this.description = description;
  }

  public String getDescription() {
    return description;
  }
}
