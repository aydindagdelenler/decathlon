package org.kuehne.enums;

/**
 * Enum class for the result file types
 */
public enum FileWriterType {
  XML
}
