package org.kuehne.enums;

/**
 * Enum class for the disciplines and their parameters in the Decathlon competition
 */
public enum Discipline {
  M100(0, "100m", 25.4347, 18, 1.81),
  LONG_JUMP(1, "Long jump", 0.14354, 220, 1.4),
  SHOT_PUT(2, "Shot put", 51.39, 1.5, 1.05),
  HIGH_JUMP(3, "High jump", 0.8465, 75, 1.42),
  M400(4, "400m", 1.53775, 82, 1.81),
  HURDLES_110M(5, "110m hurdles", 5.74352, 28.5, 1.92),
  DISCUS_THROW(6, "Discus throw", 12.91, 4, 1.1),
  POLE_VAULT(7, "Pole vault", 0.2797, 100, 1.35),
  JAVELIN_THROW(8, "Javelin throw", 10.14, 7, 1.08),
  M1500(9, "1500m race", 0.03768, 480, 1.85);

  private final int index;
  private final String name;
  private final double a;
  private final double b;
  private final double c;

  Discipline(int index, String name, double a, double b, double c) {
    this.index = index;
    this.name = name;
    this.a = a;
    this.b = b;
    this.c = c;
  }

  public int getIndex() {
    return index;
  }

  public String getName() {
    return name;
  }

  public double getA() {
    return a;
  }

  public double getB() {
    return b;
  }

  public double getC() {
    return c;
  }
}
