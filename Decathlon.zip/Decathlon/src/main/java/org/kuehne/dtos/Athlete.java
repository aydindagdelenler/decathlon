package org.kuehne.dtos;

/**
 * A DTO class stores athlete information and results for each discipline
 */
public class Athlete {
  private String name;
  private String m100;
  private String longJump;
  private String shotPut;
  private String highJump;
  private String m400;
  private String hurdles110;
  private String discusThrow;
  private String poleVault;
  private String javelinThrow;
  private String m1500;
  private int totalPoints;
  private int rank;

  public Athlete(String name, String m100, String longJump, String shotPut, String highJump,
      String m400, String hurdles110, String discusThrow, String poleVault, String javelinThrow,
      String m1500) {
    this.name = name;
    this.m100 = m100;
    this.longJump = longJump;
    this.shotPut = shotPut;
    this.highJump = highJump;
    this.m400 = m400;
    this.hurdles110 = hurdles110;
    this.discusThrow = discusThrow;
    this.poleVault = poleVault;
    this.javelinThrow = javelinThrow;
    this.m1500 = m1500;
  }

  public String getName() {
    return this.name;
  }

  public String getM100() {
    return this.m100;
  }

  public String getLongJump() {
    return this.longJump;
  }

  public String getShotPut() {
    return this.shotPut;
  }

  public String getHighJump() {
    return this.highJump;
  }

  public String getM400() {
    return this.m400;
  }

  public String getHurdles110() {
    return this.hurdles110;
  }

  public String getDiscusThrow() {
    return this.discusThrow;
  }

  public String getPoleVault() {
    return this.poleVault;
  }

  public String getJavelinThrow() {
    return this.javelinThrow;
  }

  public String getM1500() {
    return this.m1500;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setM100(String m100) {
    this.m100 = m100;
  }

  public void setLongJump(String longJump) {
    this.longJump = longJump;
  }

  public void setShotPut(String shotPut) {
    this.shotPut = shotPut;
  }

  public void setHighJump(String highJump) {
    this.highJump = highJump;
  }

  public void setM400(String m400) {
    this.m400 = m400;
  }

  public void setHurdles110(String hurdles110) {
    this.hurdles110 = hurdles110;
  }

  public void setDiscusThrow(String discusThrow) {
    this.discusThrow = discusThrow;
  }

  public void setPoleVault(String poleVault) {
    this.poleVault = poleVault;
  }

  public void setJavelinThrow(String javelinThrow) {
    this.javelinThrow = javelinThrow;
  }

  public void setM1500(String m1500) {
    this.m1500 = m1500;
  }

  public int getTotalPoints() {
    return totalPoints;
  }

  public void setTotalPoints(int totalPoints) {
    this.totalPoints = totalPoints;
  }

  public int getRank() {
    return rank;
  }

  public void setRank(int rank) {
    this.rank = rank;
  }

  public String toString() {
    return "Athlete(name=" + this.getName() + ", m100=" + this.getM100() + ", longJump="
        + this.getLongJump() + ", shotPut=" + this.getShotPut() + ", highJump=" + this.getHighJump()
        + ", m400=" + this.getM400() + ", hurdles110=" + this.getHurdles110() + ", discusThrow="
        + this.getDiscusThrow() + ", poleVault=" + this.getPoleVault() + ", javelinThrow="
        + this.getJavelinThrow() + ", m1500=" + this.getM1500() + ", totalPoints=" + this.getTotalPoints() + ", rank=" + this.getRank() + ")";
  }
}
