package org.kuehne.writers;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.enums.FileWriterType;
import org.kuehne.exceptions.RequirementException;

/**
 * A class to provide Factory Design Pattern for different file types to create as a result
 */
public class WriterFactory {

  private static final Logger logger = Logger.getLogger(WriterFactory.class.getName());
  public static FileWriter chooseWriter(FileWriterType fileWriterType) {
    if (fileWriterType.equals(FileWriterType.XML)) {
      return new XMLWriter();
    }
    logger.log(Level.SEVERE, ExceptionCode.EXTENSION_NOT_ALLOWED.getDescription());
    throw new RequirementException(ExceptionCode.EXTENSION_NOT_ALLOWED);
  }

}
