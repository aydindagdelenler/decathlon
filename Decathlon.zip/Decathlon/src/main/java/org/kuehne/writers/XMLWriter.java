package org.kuehne.writers;

import java.io.File;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.kuehne.dtos.Athlete;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * A class for writing algorithm for XML files
 */
public class XMLWriter implements FileWriter {

  private final Logger logger = Logger.getLogger(XMLWriter.class.getName());

  /**
   * Reads values from provided objects and creates XLP tags with values
   * @param athletes List of athletes
   * @param resultFilePath Path and name of the file
   */
  @Override
  public void setValuesAndCreateFile(List<Athlete> athletes, String resultFilePath) {
    try {
      DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
      Document document = documentBuilder.newDocument();

      Element root = document.createElement("decathlon");
      document.appendChild(root);

      for (Athlete athlete : athletes) {
        Element employee = document.createElement("athlete");
        root.appendChild(employee);

        Element rank = document.createElement("rank");
        rank.appendChild(document.createTextNode(String.valueOf(athlete.getRank())));
        employee.appendChild(rank);

        Element firstName = document.createElement("name");
        firstName.appendChild(document.createTextNode(String.valueOf(athlete.getName())));
        employee.appendChild(firstName);

        Element totalPoints = document.createElement("total_points");
        totalPoints.appendChild(document.createTextNode(String.valueOf(athlete.getTotalPoints())));
        employee.appendChild(totalPoints);

        Element m100 = document.createElement("meters_100");
        m100.appendChild(document.createTextNode(athlete.getM100()));
        employee.appendChild(m100);

        Element longJump = document.createElement("long_jump");
        longJump.appendChild(document.createTextNode(athlete.getLongJump()));
        employee.appendChild(longJump);

        Element shotPut = document.createElement("shot_put");
        shotPut.appendChild(document.createTextNode(athlete.getShotPut()));
        employee.appendChild(shotPut);

        Element highJump = document.createElement("high_jump");
        highJump.appendChild(document.createTextNode(athlete.getHighJump()));
        employee.appendChild(highJump);

        Element m400 = document.createElement("meters_400");
        m400.appendChild(document.createTextNode(athlete.getM400()));
        employee.appendChild(m400);

        Element hurdles110 = document.createElement("hurdles_110_meters");
        hurdles110.appendChild(document.createTextNode(athlete.getHurdles110()));
        employee.appendChild(hurdles110);

        Element discusThrow = document.createElement("discus_throw");
        discusThrow.appendChild(document.createTextNode(athlete.getDiscusThrow()));
        employee.appendChild(discusThrow);

        Element poleVault = document.createElement("pole_vault");
        poleVault.appendChild(document.createTextNode(athlete.getPoleVault()));
        employee.appendChild(poleVault);

        Element javelinThrow = document.createElement("javelin_throw");
        javelinThrow.appendChild(document.createTextNode(athlete.getJavelinThrow()));
        employee.appendChild(javelinThrow);

        Element m1500 = document.createElement("meters_1500");
        m1500.appendChild(document.createTextNode(athlete.getM1500()));
        employee.appendChild(m1500);
      }

      writeFile(document, new File(resultFilePath));
    } catch (ParserConfigurationException | TransformerException pce) {
      logger.log(Level.SEVERE, pce.getMessage());
    }
  }

  /**
   * Creates XML file
   * @param doc
   * @param output
   * @throws TransformerException
   */
  private void writeFile(Document doc, File output) throws TransformerException {
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(output);

    transformer.transform(source, result);
  }
}
