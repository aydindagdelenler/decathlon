package org.kuehne.writers;

import java.util.List;
import org.kuehne.dtos.Athlete;

/**
 * An interface class for file writer classes
 */
public interface FileWriter {

  void setValuesAndCreateFile(List<Athlete> athletes, String resultFilePath);
}
