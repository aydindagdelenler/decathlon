package org.kuehne.services;

import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.enums.FileReaderType;
import org.kuehne.exceptions.RequirementException;
import org.kuehne.readers.FileReader;

/**
 * A service class to validate if the file is allowed to use and read the values from the file
 */
public class ReaderService {

  private final Logger logger = Logger.getLogger(ReaderService.class.getName());

  private FileReader fileReader;

  /**
   * Reads values in the provided file
   *
   * @param filePath Path and name of the file
   * @return List of values by line in the file
   */
  public List<Athlete> readFile(String filePath) {
    if(validateFileExtension(filePath)) {
      return fileReader.readFile(filePath);
    }
    else {
      logger.log(Level.SEVERE, ExceptionCode.EXTENSION_NOT_ALLOWED.getDescription());
      throw new RequirementException(ExceptionCode.EXTENSION_NOT_ALLOWED);
    }
  }

  /**
   * Validates if provided file is allowed to use
   *
   * @param filePath Path and name of the file
   * @return True if allowed, false if not
   */
  private boolean validateFileExtension(String filePath) {
    Optional<String> fileExtension = getExtension(filePath);

    if (fileExtension.isPresent()) {
      for (FileReaderType type : FileReaderType.values()) {
        if (type.name().equalsIgnoreCase(fileExtension.get())) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Gets only the extension of the provided file
   *
   * @param filePath Path and name of the file
   * @return Extension of the file
   */
  private Optional<String> getExtension(String filePath) {
    return Optional.ofNullable(filePath)
        .filter(f -> f.contains("."))
        .map(f -> f.substring(filePath.lastIndexOf(".") + 1));
  }

  public void setFileReader(FileReader fileReader) {
    this.fileReader = fileReader;
  }
}
