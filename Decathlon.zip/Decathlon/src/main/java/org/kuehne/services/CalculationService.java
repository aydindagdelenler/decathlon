package org.kuehne.services;

import java.util.Arrays;
import java.util.List;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.Discipline;

/**
 * A service class to make total point calculation according to results and discipline
 */
public class CalculationService {

  /**
   * Calculates final point for competition
   * @param athlete A DTO that holding results for each discipline
   * @return Total point
   */
  public int calculateTotalPoint(Athlete athlete) {
    int m100 = calculateEventScore(athlete.getM100(), Discipline.M100);
    int longJump = calculateEventScore(athlete.getLongJump(), Discipline.LONG_JUMP);
    int shotPut = calculateEventScore(athlete.getShotPut(), Discipline.SHOT_PUT);
    int highJump = calculateEventScore(athlete.getHighJump(), Discipline.HIGH_JUMP);
    int m400 = calculateEventScore(athlete.getM400(), Discipline.M400);
    int hurdles = calculateEventScore(athlete.getHurdles110(), Discipline.HURDLES_110M);
    int discus = calculateEventScore(athlete.getDiscusThrow(), Discipline.DISCUS_THROW);
    int pole = calculateEventScore(athlete.getPoleVault(), Discipline.POLE_VAULT);
    int javelin = calculateEventScore(athlete.getJavelinThrow(), Discipline.JAVELIN_THROW);
    int m1500 = calculateEventScore(convertTimeToSec(athlete.getM1500()), Discipline.M1500);
    return m100+longJump+shotPut+highJump+m400+hurdles+discus+pole+javelin+m1500;
  }

  /**
   * Converts given time to seconds
   *
   * @param time A value including minutes and seconds
   * @return Seconds
   */
  private String convertTimeToSec(String time){
    if (!time.equals("0") && time.contains(":")) {
      List<String> items = Arrays.asList(time.split(":"));
      double convertedTime = (60 * Integer.parseInt(items.get(0))) + Double.parseDouble(items.get(1));
      return String.valueOf(convertedTime);
    }
    return "0";
  }

  /**
   * Calculates final points for a given discipline
   * @param result A value for an athlete achieved for a single discipline
   * @param discipline Specific discipline
   * @return Point for a specified discipline
   */
  private int calculateEventScore(String result, Discipline discipline) {
    if (!result.isEmpty() && !result.equals("0")) {
      double convertedResult = Double.parseDouble(result);
      if (discipline.equals(Discipline.LONG_JUMP) || discipline.equals(Discipline.HIGH_JUMP)
          || discipline.equals(Discipline.POLE_VAULT)) {
        convertedResult = convertedResult * 100;
      }
      return (int) (discipline.getA() * Math.pow(Math.abs(discipline.getB() - convertedResult),
          discipline.getC()));
    }
    return 0;
  }
}
