package org.kuehne.services;

import java.util.List;
import org.kuehne.dtos.Athlete;
import org.kuehne.writers.FileWriter;

/**
 * A service class to create a file
 */
public class WriterService {

  private FileWriter fileWriter;

  /**
   * Sets values in the object
   * @param athletes List of athletes
   */
  public void setValuesAndCreateFile(List<Athlete> athletes, String resultFilePath) {
    fileWriter.setValuesAndCreateFile(athletes, resultFilePath);
  }

  public void setFileWriter(FileWriter fileWriter) {
    this.fileWriter = fileWriter;
  }
}
