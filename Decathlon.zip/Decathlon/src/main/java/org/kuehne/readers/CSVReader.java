package org.kuehne.readers;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.exceptions.RequirementException;

/**
 * A class for reading algorithm for CSV files
 */
public class CSVReader implements FileReader{

  private final Logger logger = Logger.getLogger(CSVReader.class.getName());

  /**
   * Reads values from provided CSV file
   * @param filePath Path and name of the CSV file
   * @return List of values by line in the CSV file
   */
  @Override
  public List<Athlete> readFile(String filePath) {
    List<Athlete> athletes = new ArrayList<>();
    Path pathToFile = Paths.get(filePath);

    try (BufferedReader br = Files.newBufferedReader(pathToFile,
        StandardCharsets.US_ASCII)) {

      String line = br.readLine();
      while (line != null) {
        String[] attributes = line.split(";");
        if (!attributes[0].isEmpty()) {
          Athlete athlete = createAthlete(attributes);
          athletes.add(athlete);
          line = br.readLine();
        } else {
          break;
        }
      }
    } catch (IOException ioe) {
      logger.log(Level.SEVERE, ioe.getMessage());
      throw new RequirementException(ExceptionCode.EXCEPTION_READING_FILE);
    }
    return athletes;
  }

  /**
   * Creates an athlete object
   * @param attributes List of results for each discipline
   * @return created athlete object
   */
  private Athlete createAthlete(String[] attributes) {
    try {
      String name = attributes[0];
      String m100 = attributes[1];
      String longJump = attributes[2];
      String shotPut = attributes[3];
      String highJump = attributes[4];
      String m400 = attributes[5];
      String hurdles110 = attributes[6];
      String discusThrow = attributes[7];
      String poleVault = attributes[8];
      String javelinThrow = attributes[9];
      String m1500 = attributes[10];

      return new Athlete(name, m100, longJump, shotPut, highJump, m400, hurdles110, discusThrow,
          poleVault, javelinThrow, m1500);
    }
    catch (ArrayIndexOutOfBoundsException err) {
      logger.log(Level.SEVERE, ExceptionCode.NOT_ALL_RESULTS_AVAILABLE.getDescription());
      throw new RequirementException(ExceptionCode.NOT_ALL_RESULTS_AVAILABLE);
    }
  }
}
