package org.kuehne.readers;

import java.util.List;
import org.kuehne.dtos.Athlete;

/**
 * An interface class for file reader classes
 */
public interface FileReader {

  List<Athlete> readFile(String filePath);
}
