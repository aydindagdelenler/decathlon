package org.kuehne.readers;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.kuehne.enums.ExceptionCode;
import org.kuehne.enums.FileReaderType;
import org.kuehne.exceptions.RequirementException;

/**
 * A class to provide Factory Design Pattern for different file types to read
 */
public class ReaderFactory {
  private static final Logger logger = Logger.getLogger(ReaderFactory.class.getName());
  public static FileReader chooseReader(FileReaderType fileReaderType) {
    if (fileReaderType.equals(FileReaderType.CSV)) {
      return new CSVReader();
    }
    logger.log(Level.SEVERE, ExceptionCode.EXTENSION_NOT_ALLOWED.getDescription());
    throw new RequirementException(ExceptionCode.EXTENSION_NOT_ALLOWED);
  }

}
