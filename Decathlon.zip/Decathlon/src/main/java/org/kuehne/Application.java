package org.kuehne;

import java.util.List;
import java.util.stream.Collectors;
import org.kuehne.dtos.Athlete;
import org.kuehne.enums.FileReaderType;
import org.kuehne.enums.FileWriterType;
import org.kuehne.readers.ReaderFactory;
import org.kuehne.services.CalculationService;
import org.kuehne.services.ReaderService;
import org.kuehne.services.WriterService;
import org.kuehne.writers.WriterFactory;

public class Application {

  private static final String FILE_PATH = "src/main/resources/results.csv";
  private static final String RESULT_FILE_PATH = "src/main/resources/results.xml";

  public static void main(String... args) {
    List<Athlete> athletes = readFile();

    calculateAndSetTotalPoints(athletes);
    sortByTotalPoints(athletes);

    writeFile(athletes);
  }

  private static void writeFile(List<Athlete> athletes) {
    WriterService writerService = new WriterService();
    writerService.setFileWriter(WriterFactory.chooseWriter(FileWriterType.XML));
    writerService.setValuesAndCreateFile(athletes, RESULT_FILE_PATH);
  }

  private static List<Athlete> readFile() {
    ReaderService readerService = new ReaderService();
    readerService.setFileReader(ReaderFactory.chooseReader(FileReaderType.CSV));
    return readerService.readFile(Application.FILE_PATH);
  }

  private static void calculateAndSetTotalPoints(List<Athlete> athletes) {
    CalculationService calculationService = new CalculationService();
    for (Athlete athlete : athletes) {
      athlete.setTotalPoints(calculationService.calculateTotalPoint(athlete));
    }
  }

  private static void sortByTotalPoints(List<Athlete> athletes) {
    athletes.sort(
        (Athlete o1, Athlete o2) -> Integer.compare(o2.getTotalPoints(), o1.getTotalPoints()));
    List<Integer> p = athletes.stream().map(Athlete::getTotalPoints).distinct()
        .collect(Collectors.toList());
    athletes.forEach(a -> a.setRank(p.indexOf(a.getTotalPoints()) + 1));
  }
}
